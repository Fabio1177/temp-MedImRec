import functions_framework
import requests
from google.cloud import storage
import json
import base64
import logging
import os

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Environment Variables
API_URL = os.environ.get("API_URL")
CLIENT_ID = os.environ.get("CLIENT_ID")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET")


def construct_basic_auth_header(client_id, client_secret):
    """Constructs the Basic Auth header."""
    credentials = f"{client_id}:{client_secret}"
    encoded_credentials = base64.b64encode(credentials.encode()).decode()
    return f"Basic {encoded_credentials}"

# Triggered by a change in a storage bucket
@functions_framework.cloud_event
def sap_integration(cloud_event):
    # Extract bucket and file name from the cloud event
    data = cloud_event.data
    bucket_name = data["bucket"]
    file_name = data["name"]

    logging.info(f"Cloud event triggered for bucket: {bucket_name}, file: {file_name}")

    
    # Initialize the GCS client
    storage_client = storage.Client()

    try:
        # Access the file from the bucket
        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(file_name)

        # Download the file's content as a string (for small files)
        #file_content = blob.download_as_string()
        file_content_str = blob.download_as_text()
        try:
            json_content = json.loads(file_content_str)
            logging.info(f"Parsed JSON content: {json_content}")
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error in file '{file_name}': {e}")
            logging.error(f"Content: {file_content[:500]}")  # Log part of the file content for inspection
            return

        if not API_URL:
            logging.error("Error: API_URL environment variable is not set.")
            return
        
        if not CLIENT_ID:
            logging.error("Error: CLIENT_ID environment variable is not set.")
            return
        
        if not CLIENT_SECRET:
           logging.error("Error: CLIENT_SECRET environment variable is not set.")
           return
        
        auth_header = construct_basic_auth_header(CLIENT_ID, CLIENT_SECRET)
        headers = {
            "Authorization": auth_header,
            "Content-Type": "application/json"
        }
        
        logging.info(f"Making POST request to: {API_URL}")

        # Make a POST request to the API with the file content
        try:
            response = requests.post(API_URL, json=json_content, headers=headers, timeout=30) #Add a timeout
            print(response.status_code)
            print(response.text)
            response.raise_for_status()  # Raise HTTPError for bad responses (4xx or 5xx)
            logging.info(json.dumps({"event": "api_call_success", "status_code": response.status_code, "response": response.text}))
        except Exception as e:
            logging.exception(json.dumps({"event": "api_call_error", "message": response.text}))

    except json.JSONDecodeError as e:
        logging.error(json.dumps({"event": "json_decode_error", "message": str(e), "file_content": file_content_str[:500]}))
    except Exception as e:
        logging.exception(json.dumps({"event": "function_error", "message": str(e)}))
    