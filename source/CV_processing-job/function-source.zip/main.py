import functions_framework

from cloudevents.http import CloudEvent

import os
import io
import json
import numpy as np
import tempfile
import traceback
from google.cloud import storage
from vertexai.generative_models import Part, Image
from skill_match import SkillMatch
from gcp_tools import GCPTools
from aux_functions import AuxFuntions


# ---------------PROMPTS-----------------------------

# First step is to extract all information into json format.
prompt_1 = """Return the CV translated into English in Json format.
    Set the mother tongue of the person with proficiency level 'C2_Mastery' and take close attention to any visual indicator in the language category to map the language proficiency to one of the following categories:["A1 Beginner", "A2 Elementary", "B1/B2 Intermediate", "C1 Advanced", "C2 Mastery"].
    Transform dates into this format: MM-YYYY. For example, July 2019 transforms into 07-2019. If there is no month specified default value is 01. If there is a day discard it we only want the following format: MM-YYYY. 
"""


# Second step is formatting data with a specific json schema
prompt_2 = """Return the resume in JSON format.
    Required keys:
        -General information: Should contain personal information and summary, for the country of birth return the ISO 3166-1 alpha-3 code.
        -Employment history.
        -Education: Should contain courses and education. The courses key should include any attended conferences too.
        -Accomplishments: Should contain volunteer activities and professional achievements. The professional achievements key should include any important achievement or project completed too.
        -Skills: Should contain these keys:
            +Languages: Spoken languages, not programming languages, those go in the Technical skills field.
            +Soft skills
            +Business skills
            +Technical skills
            +Certifications
    Be flexible in classifying information. Understand the essence of the information and fit it into the most appropriate category in the required keys, even if the titles don't match exactly.
    If you don't have information of a key, leave null value."""


# Third step is extracting precise data about proficiency, years of experience and last year used for the keys of the 'skills' field
prompt_3_a = """I will send you a resume and a list of skills extracted from the resume.
    I need you to find out the skill proficiency, years of experience and the last year the skill was used for each skill.
    To find out the last year the skill was used and years of experience in that skill, check over the projects, education and work experience of the resume. If last year used is current year, set 'Ongoing'.
    To find out the skill proficiency, follow these steps:
        1.A Is there any visual indicator stating proficiency of the skill?
            - Yes -> go to 1.B
            - No -> go to 2
        1.B Use these rules:
            - The score is out of five -> 1/5: Novice, 2/5: Junior, 3/5: Proficient, 4/5: Senior, 5/5: Expert
            - The score is out of three -> 1/3: Novice, 2/3: Proficient, 3/3: Expert
        2 Any text stating the proficiency?
            - Yes -> Map proficiency through text
            - No -> go to 3
        3.A Any employment history that relates to the skill?
            - Yes -> go to 3.B
            - No -> go to 4
        3.B How many years of employment?
            - less than 1 year -> Novice
            - 1-2 years -> Junior
            - 3-4 years -> Proficient
            - 5-8 years -> Senior
            - more than 8 years -> Expert
        4. Does the person have a doctorate in the field of the skill?
            - Yes -> Map to Senior
            - No -> go to 5
        5. Does the person have a masters in the field of the skill?
            - Yes -> Map to Proficient
            - No -> Map to Junior
"""


# Initialize global clients and configurations
skill_match = SkillMatch()
aux_functions = AuxFuntions()
gcp_tools = GCPTools(
    default_project=os.getenv("GCP_PROJECT", "coc-medimrec-poc"),
    default_location=os.getenv("GCP_LOCATION", "us-central1"),
    default_bucket=os.getenv("GCP_BUCKET", "coc-mypp-sap-integration"),
    default_gen_model="gemini-2.0-flash-exp",
    default_max_tokens=8192,
    default_temperature=0.0,
    default_top_p=0.95,
)


# Triggered by a change in a storage bucket
@functions_framework.cloud_event
# Cloud Function Entry Point
def process_cv(cloud_event: CloudEvent):
    try:
        event_data=cloud_event.data
        file_name = event_data["name"]

        # Download the file
        storage_client = storage.Client()
        source_bucket = storage_client.bucket(event_data["bucket"])
        if not source_bucket.exists():
            raise ValueError(f"Bucket '{event_data['bucket']}' does not exist.")
        source_blob = source_bucket.blob(file_name)
        if not source_blob.exists():
            raise ValueError(f"File {event_data['name']} does not exist in bucket '{event_data['bucket']}'.")

        base,file_extension = os.path.splitext(file_name)

        # Handle .docx and .pdf files
        if file_extension not in [".docx", ".pdf", ".jpeg"]:
            return {"error": "Unsupported file type. Only .docx, .pdf, and .jpeg are allowed."}, 400

        with tempfile.NamedTemporaryFile(delete=False, suffix=file_extension) as temp_file:
            source_blob.download_to_filename(temp_file.name)
            file_path = temp_file.name

        if file_extension == ".docx":
            file_path = aux_functions.word_to_pdf(file_path)

        if file_extension ==".pdf":
            merged_image_path = aux_functions.file_pdf2im_merge(file_path)
        elif file_extension == ".jpeg":
            merged_image_path = file_path


        # Preloaded embeddings and skills
        embeddings_blob = storage_client.bucket("my-pp").blob("cluster_skills_embeddings.npy")
        skills_blob = storage_client.bucket("my-pp").blob("Skills.xlsx")
        major_blob = storage_client.bucket("my-pp").blob("cluster_majors_embeddings.npy")
        major_list_blob = storage_client.bucket("my-pp").blob("major_list.xlsx")
        embeddings = np.load(io.BytesIO(embeddings_blob.download_as_bytes()))
        major_embeddings = np.load(io.BytesIO(major_blob.download_as_bytes()))
        skills = skill_match.skill_list3(skills_blob.download_as_bytes())
        major_list=skill_match.major_list(major_list_blob.download_as_bytes())


        languages_list = [
            item.split(":")[2]
            for item in skills
            if len(item.split(":")) == 3 and item.startswith("Languages:Languages")
        ]

        # Generate content
        image = Part.from_image(Image.load_from_file(merged_image_path))
        content = [image, prompt_1]
        plain_cv = gcp_tools.generate(
            contents=content,
            response_type=1,
            temperature=0.2
        )

        # Format CV JSON
        prompt_2_c = prompt_2 + f"\n\n```resume\n{plain_cv}\n```"
        formatted_cv = gcp_tools.generate(
            prompt=prompt_2_c,
            response_type=2,
            response_mime_type="application/json",
            temperature=0.6
        )
        formatted_cv_json = json.loads(aux_functions.parse_json(formatted_cv))
        

        # Add skill details
        complete_cv = aux_functions.detail_skills(formatted_cv_json, prompt_3_a, image)
        #Add education details
        major_cv=skill_match.map_major_gecko(complete_cv,major_list,major_embeddings)        
        final_cv = skill_match.map_skills_gecko(major_cv, skills, embeddings, languages_list)
        user_id="A898306"
        final_cv["generalInformation"]["personalInformation"]["userID"]=user_id


        #RETURN PAYLOAD THAT IS CURRENTLY ACCEPTED THIS WILL CHANGE IN THE FUTURE
        keys_to_remove={"accomplishments","employmentHistory"}
        filtered_cv= {k: v for k, v in final_cv.items() if k not in keys_to_remove}
        del filtered_cv["skills"]["certifications"]
        del filtered_cv["generalInformation"]["personalInformation"]["dateOfBirth"]
        filtered_cv["skills"]["businessSkills"]=[]
        filtered_cv["skills"]["softSkills"]=[]
        for language in filtered_cv["skills"]["languages"]:
            language["language"]=language["NEWSKILL"]
            del language["NEWSKILL"] 
        for tech in filtered_cv["skills"]["technicalSkills"]:
            tech["technicalSkill"]=tech["NEWSKILL"]
            del tech["NEWSKILL"]
            del tech["yearsOfExperience"]
            del tech["lastYearUsed"]


        # Upload processed CV in JSON format to the cv_output folder
        output_filename = f"{base}.json"
        destination_blob_name = f"{output_filename}"
        upload_message = gcp_tools.upload_dict_to_gcs(
            filtered_cv, 
            bucket_name="coc-mypp-processed-cv",  
            destination_blob_name=destination_blob_name
        )

        # Move the original CV to the "processed" folder
        destination_blob_name_processed = f"{file_name}"
        destination_bucket = "coc-mypp-processed-pdf"
        gcp_tools.copy_blob(event_data["bucket"],event_data["name"],destination_bucket,destination_blob_name_processed)
        source_blob.delete()

        return {
            "message": upload_message,
            "cv_json": filtered_cv,
            "processed_file_location": destination_blob_name_processed
        }

    except Exception as e:
        # Move the original CV to the "error" folder
        destination_blob_name_processed = f"{file_name}"
        destination_bucket = " coc-mypp-failed-cv"
        gcp_tools.copy_blob(event_data["bucket"],event_data["name"],destination_bucket,destination_blob_name_processed)
        source_blob.delete()
        error_message = f"Error processing file: {str(e)}"
        print(error_message)
        print(traceback.format_exc())
        return {"error": error_message}, 500
