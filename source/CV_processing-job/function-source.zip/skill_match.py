import pandas as pd
import json
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from aux_functions import AuxFuntions
from gcp_tools import GCPTools
import concurrent.futures
import os
import io

aux_functions=AuxFuntions()

gcp_tools = GCPTools(
    default_project=os.getenv("GCP_PROJECT", "coc-medimrec-poc"),
    default_location=os.getenv("GCP_LOCATION", "us-central1"),
    default_bucket=os.getenv("GCP_BUCKET", "coc-mypp-sap-integration"),
    default_gen_model="gemini-1.5-pro-002",
    default_max_tokens=8192,
    default_temperature=0.0,
    default_top_p=0.95,
)
class SkillMatch():
    def __init__(self):
        pass
    
    def major_list(self, xlsx_data: bytes):
        # Load the Excel file into a DataFrame
        excel_file = io.BytesIO(xlsx_data)
        df = pd.read_excel(excel_file, engine='openpyxl')

        # Extract the three columns by name (replace with actual column names)
        column1_name = 'Major'  # Replace with the actual column name for column 1
        df = df.dropna(subset=[column1_name])

        # Drop NaN values and convert to lists
        column1_data = df[column1_name].dropna().tolist()

        # Clean up the skill descriptions and combine them into the desired format
        combined_list = []
        for i in range(len(column1_data)):
            # Format as item_column1:item_column2:item_column3
            combined_item = f"{column1_data[i].strip()}"
            combined_list.append(combined_item)

        return combined_list

    def skill_list3(self, xlsx_data: bytes):
        # Load the Excel file into a DataFrame
        excel_file = io.BytesIO(xlsx_data)
        df = pd.read_excel(excel_file, engine='openpyxl')

        # Extract the three columns by name (replace with actual column names)
        column1_name = 'Skill Section Description'  # Replace with the actual column name for column 1
        column2_name = 'Skill Family Description'  # Replace with the actual column name for column 2
        column3_name = 'Skill Description'  # Replace with the actual column name for column 3
        df = df.dropna(subset=[column1_name, column2_name, column3_name])


        # Drop NaN values and convert to lists
        column1_data = df[column1_name].dropna().tolist()
        column2_data = df[column2_name].dropna().tolist()
        column3_data = df[column3_name].dropna().tolist()

        # Ensure all columns have the same length
        min_length = min(len(column1_data), len(column2_data), len(column3_data))


        # Clean up the skill descriptions and combine them into the desired format
        combined_list = []
        for i in range(min_length):
            # Format as item_column1:item_column2:item_column3
            combined_item = f"{column1_data[i].strip()}:{column2_data[i].strip()}:{column3_data[i].strip()}"
            combined_list.append(combined_item)

        return combined_list

    def separate_skill_list3_category(self,xlsx_data: bytes):
        # Load the Excel file into a DataFrame
        excel_file = io.BytesIO(xlsx_data)
        df = pd.read_excel(excel_file, engine='openpyxl')

        # Extract the three columns by name (replace with actual column names)
        column1_name = 'Skill Section Description'  # Replace with the actual column name for column 1
        column2_name = 'Skill Family Description'  # Replace with the actual column name for column 2
        column3_name = 'Skill Description'  # Replace with the actual column name for column 3
        df = df.dropna(subset=[column1_name, column2_name, column3_name])
        # Drop NaN values and convert to lists
        column1_data = df[column1_name].dropna().tolist()
        column2_data = df[column2_name].dropna().tolist()
        column3_data = df[column3_name].dropna().tolist()

        # Ensure all columns have the same length
        min_length = min(len(column1_data), len(column2_data), len(column3_data))
        tech_list = []
        business_list=[]
        language_list=[]
        certifications_list=[]
        for i in range(min_length):
            if column1_data[i]=="Technical Skills" or column1_data[i]=="Technologies" or column1_data[i]=="Methods and Standards" or column1_data[i]=="Industries" or column1_data[i]=="Offerings":
                combined_item = f"{column1_data[i].strip()}:{column2_data[i].strip()}:{column3_data[i].strip()}"
                tech_list.append(combined_item)
            if column1_data[i]=="Business Skills":
                combined_item = f"{column1_data[i].strip()}:{column2_data[i].strip()}:{column3_data[i].strip()}"
                business_list.append(combined_item)
            if column1_data[i]=="Languages":
                combined_item = f"{column1_data[i].strip()}:{column2_data[i].strip()}:{column3_data[i].strip()}"
                language_list.append(combined_item)
            if column1_data[i]=="Certifications":
                combined_item = f"{column1_data[i].strip()}:{column2_data[i].strip()}:{column3_data[i].strip()}"
                certifications_list.append(combined_item)
        return tech_list,business_list,language_list,certifications_list

    def separate_skill_list_category(self, xlsx_data: bytes):
        # Load the Excel file into a DataFrame
        excel_file = io.BytesIO(xlsx_data)
        df = pd.read_excel(excel_file, engine='openpyxl')

        # Extract the three columns by name (replace with actual column names)
        column1_name = 'Skill Section Description'  # Replace with the actual column name for column 1
        column2_name = 'Skill Family Description'  # Replace with the actual column name for column 2
        column3_name = 'Skill Description'  # Replace with the actual column name for column 3
        df = df.dropna(subset=[column1_name, column2_name, column3_name])
        # Drop NaN values and convert to lists
        column1_data = df[column1_name].dropna().tolist()
        column2_data = df[column2_name].dropna().tolist()
        column3_data = df[column3_name].dropna().tolist()

        # Ensure all columns have the same length
        min_length = min(len(column1_data), len(column2_data), len(column3_data))
        tech_list = []
        business_list=[]
        language_list=[]
        certifications_list=[]
        for i in range(min_length):
            if column1_data[i]=="Technical Skills" or column1_data[i]=="Technologies" or column1_data[i]=="Methods and Standards" or column1_data[i]=="Industries" or column1_data[i]=="Offerings":
                tech_list.append(column3_data[i].strip())
            if column1_data[i]=="Business Skills":
                business_list.append(column3_data[i].strip())
            if column1_data[i]=="Languages":
                language_list.append(column3_data[i].strip())
            if column1_data[i]=="Certifications":
                certifications_list.append(column3_data[i].strip())
        return tech_list,business_list,language_list,certifications_list

    def dot_product_similarity(self, skills_embedding: np.ndarray, query_embedding: np.ndarray, skills: list, threshold: float):
        """
        Calculate dot product similarity between query embeddings and skill embeddings.
        Return the skills whose similarities exceed the specified threshold along with their similarity scores.
        
        Parameters:
        - skills_embedding (np.ndarray): The embedding matrix for skills.
        - query_embedding (np.ndarray): The embedding for queries.
        - skills (list): List of skill names corresponding to the embeddings.
        - threshold (float): The similarity threshold to filter results.
        
        Returns:
        - List of tuples containing (skill, similarity) for those above the threshold.
        """
        results_list = []  # List to hold skills and their similarities matching the threshold

        # Iterate through each query and its corresponding embedding
        for q_embedding in query_embedding:
            # Compute dot products
            similarities = np.dot(skills_embedding, q_embedding)  # Compute dot product
            
            # Get indices of skills that exceed the threshold
            above_threshold_indices = np.where(similarities >= threshold)[0]
            
            # Collect matching skills based on the threshold
            for idx in above_threshold_indices:
                top_match = skills[idx].strip()  # Get the skill name
                similarity_score = similarities[idx]  # Get the similarity score
                results_list.append((top_match, similarity_score))  # Append a tuple of (skill, similarity)
        results_list.sort(key=lambda x: x[1], reverse=True)
        return results_list

    def find_top_k_closest_embedding(self, embeddings: np.ndarray, query_embedding: np.ndarray, skills: list, threshold: float):
        """
        Find skills with embeddings closest to the query embedding using cosine similarity,
        filtered by a threshold and sorted in descending order.
        
        Parameters:
        - embeddings (np.ndarray): Array of all embeddings (shape: [num_embeddings, embedding_dim]).
        - query_embedding (np.ndarray): The embedding to compare against (shape: [embedding_dim]).
        - skills (list): List of skill names corresponding to each embedding.
        - threshold (float): Minimum similarity threshold to include a skill in the results.

        Returns:
        - List of tuples with each skill and its similarity, ordered by similarity in descending order.
        """
        # Compute cosine similarities between the query embedding and all other embeddings
        similarities = cosine_similarity([query_embedding], embeddings)[0]  # Shape: [num_embeddings]

        # Filter skills with similarity above the threshold
        top_skills = [(skills[idx], similarities[idx]) for idx in range(len(skills)) if similarities[idx] >= threshold]

        # Sort filtered skills by similarity in descending order
        top_skills.sort(key=lambda x: x[1], reverse=True)

        return top_skills

    def map_degree_labels_in_dict(self,data: dict) -> dict:
        """
        Maps degree values within an 'education' key of a dictionary to their
        corresponding labels based on the provided image.

        Args:
            data: A dictionary that may contain an 'education' key with degree information.

        Returns:
            A modified dictionary with mapped degree labels.
        """
        degree_mapping = {
            "Other": "degree_Other",
            "High School Diploma": "degree_High_Diploma",
            "General Education Diploma": "degree_GED",
            "Associate Degree": "degree_Associates",
            "Trade School": "degree_Trade_School",
            "Bachelor Degree": "degree_Bachelors",
            "Master Degree": "degree_Masters",
            "Doctorate / Ph.D": "degree_Doctorate",
        }

        for education in data:
            if 'degree' in education and education['degree'] in degree_mapping:
                education['degree'] = degree_mapping[education['degree']]
        return data
    def map_majors_labels_in_dict(self,data: dict) -> dict:
        major_mapping = {
            "Accounting": "major_Accounting",
            "Anthropology": "major_Anthropology",
            "Architecture": "major_Architecture",
            "Arts": "major_Arts",
            "Biological Science": "major_Biological_Science",
            "Biology": "major_Biology",
            "Business": "major_Business",
            "Chemical Engineering": "major_Chemical_Engineering",
            "Chemistry": "major_Chemistry",
            "Civil Engineering": "major_Civil_Engineering",
            "Communication": "major_Communication",
            "Comparative Literature": "major_Comparative_Literature",
            "Computer Science": "major_Computer_Science",
            "Criminal Justice": "major_Criminal_Justice",
            "Design": "major_Design",
            "Drafting": "major_Drafting",
            "Economics": "major_Economics",
            "Education": "major_Education",
            "Electrical Engineering": "major_Electrical_Engineering",
            "Electronics": "major_Electronics",
            "Engineering General": "major_Engineering_General",
            "Engineering Management": "major_Engineering_Management",
            "English": "major_English",
            "Environmental Engineering": "major_Environmental_Engineering",
            "Environmental Science": "major_Environmental_Science",
            "Film": "major_Film",
            "Finance": "major_Finance",
            "Fine Arts": "major_Fine_Arts",
            "Foreign Language": "major_Foreign_Language",
            "Forestry": "major_Forestry",
            "General Studies": "major_General_Studies",
            "Geography": "major_Geography",
            "Geology": "major_Geology",
            "Government": "major_Government",
            "Healthcare": "major_Healthcare",
            "History": "major_History",
            "Hospitality Management": "major_Hospitality_Management",
            "Human Resources": "major_Human_Resources",
            "Information Systems": "major_Information_Systems",
            "Law": "major_Law",
            "Liberal Arts": "major_Liberal_Arts",
            "Linguistics": "major_Linguistics",
            "Literature": "major_Literature",
            "Management": "major_Management",
            "Marketing": "major_Marketing",
            "Mathematics": "major_Mathematics",
            "Mechanical Engineering": "major_Mechanical_Engineering",
            "Media": "major_Media",
            "Music": "major_Music",
            "Nursing": "major_Nursing",
            "Organisation Development": "major_Organization_Development",
            "Other": "major_Other",
            "Other Technology": "major_Other_Technology",
            "Pharmacy": "major_Pharmacy",
            "Philosophy": "major_Philosophy",
            "Physics": "major_Physics",
            "Political Science": "major_Political_Science",
            "Psychology": "major_Psychology",
            "Public Relations": "major_Public_Relations",
            "Religion": "major_Religion",
            "Science": "major_Science",
            "Sociology": "major_Sociology",
            "Statistics": "major_Statistics",
            "Theatre": "major_Theatre",
            "Visual Arts": "major_Visual_Arts"
        }
        for education in data:
            if 'major' in education and education['major'] in major_mapping:
                education['major'] = major_mapping[education['major']]
        return data
    
    def map_major_gecko(self, data: dict, skill_list: list, embeddings: np.ndarray):
        query_list=[]
        if 'education' in data["education"]:
            education_data=data["education"]["education"]
            self.map_degree_labels_in_dict(education_data)
            for  education in education_data:
                query=education["major"]
                query_list.append(query)
            query_em = gcp_tools.gecko_embedding("textembedding-gecko@003", 250, query_list,task="CLUSTERING")
            for idx, major in enumerate(query_list):
                match_list = []
                match = self.find_top_k_closest_embedding(embeddings, query_em[idx], skill_list, 0.7)
                for i, (match_skill, score) in enumerate(match):
                    match_list.append(match_skill)
                contents = f"""You have to match the major provided '{query_list[idx]}' with one of the following majors\n
                                {match_list}. Return the exact matched major name. If you cannot match it to anything return None"""
                            
                match_result = gcp_tools.generate(
                    contents=contents,
                    response_type=6,
                    response_mime_type="application/json",
                    system_instruction="You are an HR employee",
                    gen_model="gemini-1.5-pro-002",
                    temperature=0
                )
                match_result=aux_functions.parse_json(match_result)
                match_result=json.loads(match_result)
                    # Update or mark for removal based on match result
                if match_result["major"] == "None":
                    data["education"]["education"][idx]["major"] = "Other"
                else:
                    data["education"]["education"][idx]["major"] = match_result["major"]

            self.map_majors_labels_in_dict(education_data)

        return data
     
    def map_skills_gecko(self, data: dict, skill_list: list, embeddings: np.ndarray, languages_list: list):
        section = ["technicalSkills", "businessSkills", "certifications", "languages"]
        skill_name = ["technicalSkill", "businessSkill", "certificationDescription", "language"]
        query_append = ["Technologies:", "Business Skills:", "Certifications:", ""]
        
        if 'skills' in data:
            skills_data = data['skills']
            for index, category in enumerate(section):
                if skills_data[category] != []:
                    query_list = []  # List for query strings to embed
                    skills = data["skills"][category]  # Skill list for current category
                    to_remove = []  # Track indices of items to remove

                    # Format skill descriptions and prepare queries
                    for idx, skill in enumerate(skills):
                        query = data["skills"][category][idx][skill_name[index]]
                        query = f'{query_append[index]}{query}'  # Add prefix to query for context
                        query_list.append(query)

                    # For non-language categories, use embeddings
                    if category != "languages":
                        query_em = gcp_tools.gecko_embedding("textembedding-gecko@003", 250, query_list,task="CLUSTERING")
                        for idx, skill in enumerate(skills):
                            match_list = []
                            match = self.find_top_k_closest_embedding(embeddings, query_em[idx], skill_list, 0.88)
                            if match == []:
                                to_remove.append(skill)  # Mark for removal if no match
                            else:
                                for i, (match_skill, score) in enumerate(match):
                                    match_list.append(match_skill)

                                contents = f"""You have to match the query skill provided '{query_list[idx]}' with one of the following skills\n
                                    {match_list}. If the query is too general and the skill is too specific or it doesn't match any skill, return null; otherwise, return the exact matched skill name."""
                                
                                match_result = gcp_tools.generate(
                                    contents=contents,
                                    response_type=5,
                                    response_mime_type="application/json",
                                    system_instruction="You are an HR employee",
                                    gen_model="gemini-1.5-pro-002",
                                    temperature=0.6
                                )
                                match_result=aux_functions.parse_json(match_result)
                                match_result=json.loads(match_result)
                                # Update or mark for removal based on match result
                                if match_result["name_newSkill"] == "null":
                                    to_remove.append(skill)
                                else:
                                    data["skills"][category][idx]["NEWSKILL"] = match_result["name_newSkill"]
                    else:
                        # For languages, match directly with list and remove non-matches
                        for idx, language in enumerate(query_list):
                            # Perform exact case-insensitive match
                            if any(language.lower() == lang.lower() for lang in languages_list):
                                data["skills"][category][idx]["NEWSKILL"] = language
                            else:
                                to_remove.append(data["skills"][category][idx])
                # Remove items marked for deletion
                data["skills"][category] = [item for item in data["skills"][category] if item not in to_remove]
                                                                    
            return data