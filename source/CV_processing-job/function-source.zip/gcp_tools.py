import vertexai
import os
import time
import json
import numpy as np
from vertexai.generative_models import GenerationConfig, GenerativeModel, SafetySetting
from vertexai.language_models import TextEmbeddingModel, TextEmbeddingInput
from google.cloud import storage, aiplatform


class GCPTools():
    def __init__(self,
                 default_project: str,
                 default_location: str,
                 default_bucket: str,
                 default_gen_model: str,
                 default_max_tokens: int,
                 default_temperature: float,
                 default_top_p: float,
                 default_safety_settings: list = [
                    SafetySetting(
                        category=SafetySetting.HarmCategory.HARM_CATEGORY_HATE_SPEECH,
                        threshold="OFF"
                    ),
                    SafetySetting(
                        category=SafetySetting.HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
                        threshold="OFF"
                    ),
                    SafetySetting(
                        category=SafetySetting.HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
                        threshold="OFF"
                    ),
                    SafetySetting(
                        category=SafetySetting.HarmCategory.HARM_CATEGORY_HARASSMENT,
                        threshold="OFF"
                    ),
                ]
            ):
        
        self.default_project = default_project
        self.default_location = default_location
        self.default_bucket = default_bucket
        self.default_gen_model = default_gen_model
        self.default_max_tokens = default_max_tokens
        self.default_temperature = default_temperature
        self.default_top_p = default_top_p
        self.default_safety_settings = default_safety_settings
        self.gemini_calls_retried = 0

    def generate(self,
                 response_type: int,
                 prompt: str = None,
                 contents: list = None,
                 system_instruction: str = None,
                 response_schema: dict = None,
                 response_mime_type: str = None,
                 project: str = None,
                 location: str = None,
                 gen_model: str = None,
                 temperature: float = None,
                 max_tokens: int = None,
                 top_p: float = None
                 ):
        
        default_contents = [prompt]

        match response_type:
            case 1:
                response_schema = None
            case 2:
                response_schema = response_type_1
            case 3:
                response_schema = response_type_2
            case 4:
                response_schema = response_type_3
            case 5:
                response_schema = response_type_4
            case 6:
                response_schema = response_type_5
            case 7:
                response_schema = response_type_6

        vertexai.init(project = project or self.default_project,
                      location = location or self.default_location)

        model = GenerativeModel(model_name = gen_model or self.default_gen_model,
                                system_instruction = system_instruction)
        
        try:
            responses = model.generate_content(
                contents = contents or default_contents,
                generation_config = GenerationConfig(
                    temperature = temperature or self.default_temperature,
                    max_output_tokens = max_tokens or self.default_max_tokens,
                    top_p = top_p or self.default_top_p,
                    response_mime_type = response_mime_type,
                    response_schema  = response_schema
                ),
                safety_settings = self.default_safety_settings,
            )
            return responses.text
        
        except Exception as e:
            if self.gemini_calls_retried < 15:
                self.gemini_calls_retried += 1
                print(str(e))
                time.sleep(30)
                return self.generate(response_type,
                                     prompt,
                                     contents,
                                     system_instruction,
                                     response_schema,
                                     response_mime_type,
                                     project,
                                     location,
                                     gen_model,
                                     temperature,
                                     max_tokens,
                                     top_p)
            else:
                raise Exception('Max GCP calls tried.' + f'Error: {str(e)}')

    def gecko_embedding(self, model: str,chunk_size: int,skills: list,task: str ="SEMANTIC_SIMILARITY", project: str = None, location: str = None):
        vertexai.init(project = project or self.default_project,
                      location = location or self.default_location)
        embedding_model = TextEmbeddingModel.from_pretrained(model)   #Max chunk size of 250 recommended use of 250 for faster processing
        all_embeddings=[]    
        for i in range(0, len(skills), chunk_size):
            chunk = skills[i:i + chunk_size]  # Get a chunk of skills
            chunk_embeddings = embedding_model.get_embeddings(texts=[TextEmbeddingInput(skill, task_type=task) for skill in chunk])
            
            # Append the embeddings for the current chunk to the all_embeddings list
            all_embeddings.extend([embedding.values for embedding in chunk_embeddings])
        all_embeddings = np.array(all_embeddings)
        return all_embeddings
    
    def copy_blob(self,bucket_name, blob_name, destination_bucket_name, destination_blob_name,):
        """Copies a blob from one bucket to another with a new name."""
        # bucket_name = "your-bucket-name"
        # blob_name = "your-object-name"
        # destination_bucket_name = "destination-bucket-name"
        # destination_blob_name = "destination-object-name"

        storage_client = storage.Client()

        source_bucket = storage_client.bucket(bucket_name)
        source_blob = source_bucket.blob(blob_name)
        destination_bucket = storage_client.bucket(destination_bucket_name)

        # Optional: set a generation-match precondition to avoid potential race conditions
        # and data corruptions. The request to copy is aborted if the object's
        # generation number does not match your precondition. For a destination
        # object that does not yet exist, set the if_generation_match precondition to 0.
        # If the destination object already exists in your bucket, set instead a
        # generation-match precondition using its generation number.
        # There is also an `if_source_generation_match` parameter, which is not used in this example.
        #destination_generation_match_precondition = 0

        blob_copy = source_bucket.copy_blob(
            source_blob, destination_bucket, destination_blob_name)

    def upload_dict_to_gcs(self, data, bucket_name, destination_blob_name):
        """
        Uploads a Python dictionary as a JSON file to a Google Cloud Storage bucket.

        Args:
            data (dict): The dictionary to upload.
            bucket_name (str): Name of the destination GCS bucket.
            destination_blob_name (str): The path in the bucket where the file will be stored.

        Returns:
            str: A message indicating the upload status.
        """
        try:
            # Initialize GCS client
            client = storage.Client()

            # Get the bucket
            bucket = client.bucket(bucket_name)

            # Create a new blob (file) in the bucket
            blob = bucket.blob(destination_blob_name)

            # Convert the dictionary to a JSON string
            json_data = json.dumps(data, indent=2)

            # Upload the JSON string to GCS
            blob.upload_from_string(json_data, content_type="application/json")


        except Exception as e:
            # Log and return the error
            error_message = f"Error uploading processed JSON file to GCS: {str(e)}"
            print(error_message)
            return error_message


    def upload_file(self,
                      file_name: str,
                      destination_file_name: str,
                      bucket_name: str = None):
        """Uploads a blob to the bucket."""
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name = bucket_name or self.default_bucket)
        blob = bucket.blob(blob_name = destination_file_name)

        blob.upload_from_file(file_name)
        print(f"Uploaded storage object {destination_file_name} from {file_name}.")
        loggers.add_output_logs(f"Uploaded storage object {destination_file_name} from {file_name}.")

    def download_file(self, source_file_name: str, destination_file_name: str, bucket_name: str = None):
        """Downloads a file from the specified bucket."""
        storage_client = storage.Client()
        bucket = storage_client.bucket(bucket_name or self.default_bucket)
        blob = bucket.blob(source_file_name)

        blob.download_to_filename(destination_file_name)
        print(f"Downloaded storage object {source_file_name} to {destination_file_name}.")

response_type_1 = {
    "type": "object",
    "properties": {
        "generalInformation": {
            "type": "object",
            "properties": {
                "personalInformation": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                        "mobilePhone": {"type": "string"},
                        "url": {"type": "string",
                                "description": "Write all URLs separated by commas"},
                        "country": {"type": "string"},
                        "dateOfBirth": {"type": "string"}
                    },
                    "required": ["name", "email", "mobilePhone", "url", "country", "dateOfBirth"]
                },
                "summary": {"type": "string"}
            },
            "required": ["personalInformation", "summary"]
        },
        "employmentHistory": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "employerName": {"type": "string"},
                    "startDate": {"type": "string"},
                    "endDate": {"type": "string"},
                    "jobTitle": {"type": "string"},
                    "countryReg": {"type": "string"},
                    "companyCity": {"type": "string"},
                    "description": {"type": "string"}
                },
                "required": ["employerName", "startDate", "endDate", "jobTitle", "countryReg", "companyCity", "description"]
            }
        },
        "skills": {
            "type": "object",
            "properties": {
                "softSkills": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                },
                "technicalSkills": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                },
                "businessSkills": {
                    "type": "array",
                    "items": {
                        "type": "string"
                    }
                },
                "languages": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "language": {"type": "string"},
                            "proficiency": {
                                "type": "string",
                                "description": "Mandatory", 
                                "format":"enum",
                                "enum": ["A1 Beginner", "A2 Elementary", "B1/B2 Intermediate", "C1 Advanced", "C2 Mastery"]
                                }
                        },
                        "required": ["language", "proficiency"]
                    }
                },
                "certifications": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "certificationDescription": {"type": "string"},
                            "institute": {"type": "string"},
                            "certificationDate": {"type": "string"},
                            "expiryDate": {"type": "string"}
                        },
                        "required": ["certificationDescription", "institute", "certificationDate", "expiryDate"]
                    }
                }
            },
            "required": ["softSkills", "technicalSkills", "businessSkills", "languages","certifications"]
        },
        "education": {
            "type": "object",
            "properties": {
                "education": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "startDate": {"type": "string",
                                          "description": "Use the following format MM-YYYY"},
                            "endDate": {"type": "string",
                                        "description": "Use the following format MM-YYYY"},
                            "nameOfEducation": {"type": "string"},
                            "institute": {"type": "string"},
                            "major": {
                                "type": "string",
                                "description": "The student's declared academic major. Examples include 'Computer Science', 'Biology', or 'History'.",
                                },
                            "degree": {
                                "type": "string",
                                "description": "Mandatory, estimate based on CV",
                                "format":"enum",
                                "enum": ["Other", "High School Diploma", "General Education Diploma", "Associate Degree", "Trade School", "Bachelor Degree", "Master Degree", "Doctorate / Ph.D"]
                                }
                        },
                        "required": ["startDate", "endDate", "nameOfEducation", "institute", "major", "degree"]
                    }
                },
                "courses": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "startDate": {"type": "string",
                                          "description": "Use the following format MM-YYYY"},
                            "endDate": {"type": "string",
                                        "description": "Use the following format MM-YYYY"},
                            "nameOfCourse": {"type": "string"},
                            "institute": {"type": "string"},
                            "durationHours": {"type": "string"}
                        },
                        "required": ["startDate", "endDate", "nameOfCourse", "institute", "durationHours"]
                    }
                }
            },
            "required": ["education", "courses"]
        },
        "accomplishments": {
            "type": "object",
            "properties": {
                "volunteer": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "startDate": {"type": "string"},
                            "endDate": {"type": "string"},
                            "organisationName": {"type": "string"},
                            "roleDescription": {"type": "string"}
                        },
                        "required": ["startDate", "endDate", "organisationName", "roleDescription"]
                    }
                },
                "professionalAchievements": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "properties": {
                            "startDate": {"type": "string"},
                            "endDate": {"type": "string"},
                            "description": {"type": "string"}
                        },
                        "required": ["startDate", "endDate", "description"]
                    }
                }
            },
            "required": ["volunteer", "professionalAchievements"]
        }
    },
    "required": ["generalInformation", "employmentHistory", "skills", "education", "accomplishments"]
}

response_type_2 = {
    "type": "object",
    "properties": {
        "technicalSkills": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "technicalSkill": {"type": "string"},
                    "rationale": {
                        "type": "string",
                        "description": "Mandatory. The step by step process followed to set the values of \"proficiency\", \"lasYearUsed\" and \"yearsOfExperience\"."
                        },
                    "proficiency": {
                        "type": "string",
                        "description": "Mandatory",
                        "format":"enum",
                        "enum": ["Novice", "Junior", "Proficient", "Senior", "Expert"]
                        },
                    "yearsOfExperience": {
                        "type": "integer",
                        "description": "Mandatory"
                        },
                    "lastYearUsed": {
                        "type": "string",
                        "description": "Mandatory. If it's the current year, set \"Ongoing\""
                        }
                },
                "required": ["technicalSkill", "rationale", "proficiency", "yearsOfExperience", "lastYearUsed"]
            }
        }
    },
    "required": ["technicalSkills"]
}

response_type_3 = {
    "type": "object",
    "properties": {
        "businessSkills": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "businessSkill": {"type": "string"},
                    "rationale": {
                        "type": "string",
                        "description": "Mandatory. The step by step process followed to set the values of \"proficiency\", \"lasYearUsed\" and \"yearsOfExperience\"."
                        },
                    "proficiency": {
                        "type": "string",
                        "description": "Mandatory",
                        "format":"enum",
                        "enum": ["Novice", "Junior", "Proficient", "Senior", "Expert"]
                        },
                    "yearsOfExperience": {
                        "type": "integer",
                        "description": "Mandatory"
                        },
                    "lastYearUsed": {
                        "type": "string",
                        "description": "Mandatory. If it's the current year, set \"Ongoing\""
                        }
                },
                "required": ["businessSkill", "rationale", "proficiency", "yearsOfExperience", "lastYearUsed"]
            }
        }
    },
    "required": ["businessSkills"]
}

response_type_4 = {
    "type": "object",
    "properties": {
        "name_newSkill":{"type": "string"},
        "rationale":{"type": "string"}
    },
    "required": ["name_newSkill", "rationale"]
}

response_type_5 = {
    "type": "object",
    "properties": {
        "major":{"type": "string"},
    },
    "required": ["major"]
}


# response_type_6 = {
#     "type": "object",
#     "properties": {
#         "major":{
#             "type": "string",
#             "description": "The student's declared academic major.",
#             "format":"enum",
#             "enum": [
#                         "Accounting",
#                         "Anthropology",
#                         "Architecture",
#                         "Arts",
#                         "Biological Science",
#                         "Biology",
#                         "Business",
#                         "Chemical Engineering",
#                         "Chemistry",
#                         "Civil Engineering",
#                         "Communication",
#                         "Comparative Literature",
#                         "Computer Science",
#                         "Criminal Justice",
#                         "Design",
#                         "Drafting",
#                         "Economics",
#                         "Education",
#                         "Electrical Engineering",
#                         "Electronics",
#                         "Engineering General",
#                         "Engineering Management",
#                         "English",
#                         "Environmental Engineering",
#                         "Environmental Science",
#                         "Film",
#                         "Finance",
#                         "Fine Arts",
#                         "Foreign Language",
#                         "Forestry",
#                         "General Studies",
#                         "Geography",
#                         "Geology",
#                         "Government",
#                         "Healthcare",
#                         "History",
#                         "Hospitality Management",
#                         "Human Resources",
#                         "Information Systems",
#                         "Law",
#                         "Liberal Arts",
#                         "Linguistics",
#                         "Literature",
#                         "Management",
#                         "Marketing",
#                         "Mathematics",
#                         "Mechanical Engineering",
#                         "Media",
#                         "Music",
#                         "Nursing",
#                         "Organisation Development",
#                         "Other",
#                         "Other Technology",
#                         "Pharmacy",
#                         "Philosophy",
#                         "Physics",
#                         "Political Science",
#                         "Psychology",
#                         "Public Relations",
#                         "Religion",
#                         "Science",
#                         "Sociology",
#                         "Statistics",
#                         "Theatre",
#                         "Visual Arts"
#                     ]
#         },
#     },
#     "required": ["major"]
# }

response_type_6 = {"type": "object",
    "properties": {
        "date":{"type": "string",
                "description": "Use the following format MM-YYYY"}
    },
    "required": ["date"]
}