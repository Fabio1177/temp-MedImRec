import os
import json
import fitz
from PIL import Image   
from docx2pdf import convert
import re
from gcp_tools import GCPTools
from google.cloud import storage
import tempfile
import requests
import concurrent.futures



gcp_tools = GCPTools(
    default_project=os.getenv("GCP_PROJECT", "coc-medimrec-poc"),
    default_location=os.getenv("GCP_LOCATION", "us-central1"),
    default_bucket=os.getenv("GCP_BUCKET", "coc-mypp-sap-integration"),
    default_gen_model="gemini-1.5-pro-002",
    default_max_tokens=8192,
    default_temperature=0.0,
    default_top_p=0.95,
)

class AuxFuntions():
    def __init__(self):
        pass

    def parse_json(self, rsp: str):
        pattern = r"```json(.*)```"
        match = re.search(pattern, rsp, re.DOTALL)
        parsed_schema = match.group(1) if match else rsp
        return parsed_schema

    def json_folder(self, cv: dict ,filename:str ,output_folder:str):
        os.makedirs(output_folder, exist_ok=True)
        output_path = os.path.join(output_folder,filename)
        with open(output_path, "w") as output_file:
            json.dump(cv, output_file, indent = 4)
            

    def word2pdf(self, folder_path: str):
       # Save Word file to a temporary location
            with tempfile.NamedTemporaryFile(delete=False, suffix=".docx") as temp_file:
                file_.save(temp_file.name)
                word_file_path = temp_file.name
# Initialize COM library to avoid errors with multi-threading environments
            try:
                pythoncom.CoInitialize()  # Initialize COM library

                # Open Word application in the background
                word = Dispatch("Word.Application")
                word.Visible = False  # Make Word run in the background (without GUI)

                # Open the document
                doc = word.Documents.Open(word_file_path)

                # Convert the Word document to PDF
                pdf_output_path = f"{word_file_path[:-5]}.pdf"
                doc.SaveAs(pdf_output_path, FileFormat=17)  # 17 = wdFormatPDF
                #print(f"Converted Word document to PDF: {pdf_output_path}")

                # Close the Word document and quit the Word application
                doc.Close(False)
                word.Quit()

                # Set the file path for the next processing step
                file_path = pdf_output_path

            except Exception as e:
                print(f"Error converting Word to PDF: {e}")
                return {"error": str(e)}

            finally:
                pythoncom.CoUninitialize()  # Uninitialize COM library

            file_path = pdf_output_path
    
    def file_pdf2im_merge(self, file_path: str):    
        if file_path.endswith(".pdf"):
            pdf_document = fitz.open(file_path)  # Open the PDF
            
            images = []  # Store images of each page
            
            # Loop through each page and convert to image
            for page_num in range(len(pdf_document)):
                page = pdf_document.load_page(page_num)  # Load each page
                zoom_x = 300 / 72  # Adjusting resolution (DPI)
                zoom_y = 300 / 72
                matrix = fitz.Matrix(zoom_x, zoom_y)
                
                pix = page.get_pixmap(matrix=matrix)  # Get image from the page
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                images.append(img)  # Add the image to the list
                                
            # Merge all images vertically
            if images:
                widths, heights = zip(*(i.size for i in images))
                total_width = max(widths)  # Use the maximum width
                total_height = sum(heights)  # Sum of all heights for vertical stacking
                
                # Create a new blank image with total dimensions
                merged_image = Image.new('RGB', (total_width, total_height))
                
                y_offset = 0
                for img in images:
                    merged_image.paste(img, (0, y_offset))
                    y_offset += img.height
                
                # Save the merged image
                merged_image_path = f'{file_path[:-4]}_merged.jpeg'
                merged_image.save(merged_image_path)
                            
            # Close the document after processing all pages
            pdf_document.close()
        return merged_image_path               
      
    def detail_skills(self, cv_json: dict, prompt_a: str, cv_image):
        def process_tech_skills(reduced_list, prompt_a, cv_image):
            prompt_a_aux = prompt_a + "\n***technicalSkills/technologies***\n" + "\n".join(reduced_list) + "\n***"
            contents = [prompt_a_aux, cv_image]
            described_tech_skills = gcp_tools.generate(contents=contents,
                                                    response_type=3,
                                                    response_mime_type="application/json",
                                                    temperature=0.2)
            return json.loads(self.parse_json(described_tech_skills))['technicalSkills']

        if cv_json['skills']['technicalSkills'] != []:
            prompt_a_aux = prompt_a
            described_tech_skills_dict = []
            reduced_lists = [cv_json['skills']['technicalSkills'][i:i+2] for i in range(0, len(cv_json['skills']['technicalSkills']), 2)]

            with concurrent.futures.ThreadPoolExecutor() as executor:
                # Use map to run the function concurrently for each reduced list
                results = executor.map(process_tech_skills, reduced_lists, [prompt_a]*len(reduced_lists), [cv_image]*len(reduced_lists))

                # Collect the results into described_tech_skills_dict
                for result in results:
                    described_tech_skills_dict.append(result)

            # Flatten the list
            flattened_list = [item for sublist in described_tech_skills_dict for item in sublist]
            cv_json['skills']['technicalSkills'] = flattened_list

        def process_bus_skills(reduced_list, prompt_a, cv_image):
            prompt_a_aux = prompt_a + "\n***businessSkills***\n" + "\n".join(reduced_list) + "\n***"
            contents = [prompt_a_aux, cv_image]
            described_bus_skills = gcp_tools.generate(contents=contents,
                                                    response_type=4,
                                                    response_mime_type="application/json",
                                                    temperature=0.2)
            return json.loads(self.parse_json(described_bus_skills))['businessSkills']

        if cv_json['skills']['businessSkills'] != []:
            prompt_a_aux = prompt_a
            described_bus_skills_dict = []
            reduced_lists = [cv_json['skills']['businessSkills'][i:i+2] for i in range(0, len(cv_json['skills']['businessSkills']), 2)]

            with concurrent.futures.ThreadPoolExecutor() as executor:
                # Use map to run the function concurrently for each reduced list
                results = executor.map(process_bus_skills, reduced_lists, [prompt_a]*len(reduced_lists), [cv_image]*len(reduced_lists))

                # Collect the results into described_bus_skills_dict
                for result in results:
                    described_bus_skills_dict.append(result)

            # Flatten the list
            flattened_list = [item for sublist in described_bus_skills_dict for item in sublist]
            cv_json['skills']['businessSkills'] = flattened_list


        [tech.pop("rationale") for tech in cv_json['skills']["technicalSkills"] if "rationale" in tech]
        [bus.pop("rationale") for bus in cv_json['skills']["businessSkills"] if "rationale" in bus]

        return cv_json